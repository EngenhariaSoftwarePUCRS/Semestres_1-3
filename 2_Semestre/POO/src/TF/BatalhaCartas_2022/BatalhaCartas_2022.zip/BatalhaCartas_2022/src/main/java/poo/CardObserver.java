package poo;

public interface CardObserver{
    void cardSelected(CardView card);
}

