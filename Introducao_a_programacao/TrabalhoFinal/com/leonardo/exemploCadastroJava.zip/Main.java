package com.leonardo;

import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
	    Sistema sistema = new Sistema();
        sistema.inicializarSistema();
    }
}
